package com.faers.agent.utils;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * @author zgm
 */
@Component
public class RedisUtil {
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;


    public static RedisTemplate<String, Object> redis;
    public static StringRedisTemplate stringRedis;
    @PostConstruct
    public void getRedisTemplate(){
        redis=this.redisTemplate;
        stringRedis=this.stringRedisTemplate;
    }
}
